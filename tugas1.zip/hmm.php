<?php

echo "Binatang <br>";
echo "<hr>";

class kucing{
    public $nama, $jumlah_kaki, $bisa_terbang, $tidak_bisa_terbang, $suara
}
$kucing = new kucing;
$kucing->nama = "momo";
$kucing->jumlah_kaki ="4";
$kucing->suara = "meong";

echo "kucing <br>";
echo "nama : $Kucing->nama <br>";
echo "Jumlah Kaki: $kucing->jumlah_kaki <br>";
echo "Tidak Bisa Terbang : $kucing ->tidak_bisa_terbang <br>";
echo "Suara : $kucing->suara <br>";

echo "<hr>";

class Anjing{
    public $nama, $jumlah_kaki, $bisa_terbang, $tidak_bisa_terbang, $suara
}
$anjing-> = new anjing;
$anjing->nama = "doggo";
$anjing->jumlah_kaki ="4";
$anjing->suara = "guk guk";

echo "anjing <br>";
echo "anjing : $anjing->nama <br>";
echo "Jumlah Kaki: $anjing->jumlah_kaki <br>";
echo "Tidak Bisa Terbang : $anjing ->tidak_bisa_terbang <br>";
echo "Suara : $anjing->suara <br>";

echo "<hr>";

class Elang{
    public $nama, $jumlah_kaki, $bisa_terbang, $tidak_bisa_terbang, $suara
}
$Elang-> = new Elang;
$Elang->nama = "Zya";
$Elang->jumlah_kaki ="2";
$Elang->suara = "wik wik";

echo "Elang <br>";
echo "Elang : $Elang->nama <br>";
echo "Jumlah Kaki: $Elang->jumlah_kaki <br>";
echo "Tidak Bisa Terbang : $Elang ->bisa_terbang <br>";
echo "Suara : $Elang->suara <br>";

echo "<hr>";

$Angsa-> = new Angsa;
$Angsa->nama = "Masha";
$Angsa->jumlah_kaki ="2";
$Angsa->suara = "kweeek";

echo "Angsa <br>";
echo "Angsa : $Angsa->nama <br>";
echo "Jumlah Kaki: $Angsa->jumlah_kaki <br>";
echo "Tidak Bisa Terbang : $Angsa ->bisa_terbang <br>";
echo "Suara : $Angsa->suara <br>";

echo "<hr>";
?>