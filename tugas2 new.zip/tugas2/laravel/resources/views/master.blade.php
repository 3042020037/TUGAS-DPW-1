@extends('home')
@section('content')

<section class="page-section clearfix">
    <div class="container">
      <div class="intro">
        <img class="intro-img img-fluid mb-3 mb-lg-0 rounded" src="img/intro.jpg" alt="">
        <div class="intro-text left-0 text-center bg-faded p-5 rounded">
          <h2 class="section-heading mb-4">
          
            <span class="section-heading-lower">"KOPI SIANIDA"</span>
          </h2>
          <p class="mb-3">Setiap cangkir kopi Sianida berkualitas kami dimulai dengan bahan-bahan pilihan lokal. Setelah Anda mencobanya, kopi kami akan menjadi tambahan yang menyenangkan untuk rutinitas pagi Anda setiap hari - kami jamin!
          </p>
          <div class="intro-button mx-auto">
            <a class="btn btn-primary btn-xl" href="#">Gabung lah!</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  @stop